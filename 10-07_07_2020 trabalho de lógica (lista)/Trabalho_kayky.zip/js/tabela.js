//função para validar e acrescentar linhas a tabela
function tabela() 
{
    var peso = variaveis("peso");
    var valorReais = variaveis("valorReais");
  
   
        var valor = peso * valorReais;
        var linha = "<tr><th></th><td>" + peso + " Kg</td><td>" + valorReais + "Kg</td><td>R$" + FormataTabela(valor) +
            "<button onclick='remover()'class='remover ml-5 bg-danger'>Excluir</button></td></tr>";
        $("#tabela tbody").append(linha);

        //Criação de um objeto --------------------------------------------
        function item(peso,valorReais , valor)
        {
            this.peso = peso;
            this.valorReais = valorReais;
            this.valor = valor;
        }
        
        //exibindo objeto no console
        var item1 =new  item(peso,valorReais , valor);
        console.log( item1.peso + " - " + FormataTabela(item1.valor) + " - " + item1.valorReais );
        //Final do objeto -------------------------------------------------

        //limpa campos após clicar para adicionar linha
        $('#TotalPagar').val("R$" + FormataTabela(valor));
        $('#peso').val("");
        $('#valorReais').val("");
    
}

//Função que valida o botão onde mostra a quantidade de itens e o valor
function quantidade(peso, valorReais)
{
    var peso = variaveis("peso");
    var valorReais = variaveis("valorReais");
    var valor = Number(kg) * Number(valorReais); 
    var item = peso * kg;
    $('#TotalItem').val(item+" Itens");
    $('#TotalPagar').val("R$" + valor.toFixed(2).replace('.',','));
}

//remover linha da tabela
$("#tabela").on("click", ".remover", function (e) {
    $(this).closest('tr').remove();
});

//apaga todos os itens da tabela(Precia de ajustes, pois fica o resquício do inicio da linha!)
$("#apagar").click(function () {
    $("#tabela tbody tr").remove();
});
function variaveis(variavel){
    return ($('#' + variavel).val()).replace(",", ".");
}
$("#valorReais").mask('99990,00', {reverse: true});

$("#peso").mask('99990,0999', {reverse:true});

function FormataTabela(valor){ 
    if(typeof valor != "number"){
        valor = valor.replace("R$", "");
        valor = Number(valor);
    }
        return valor.toFixed(2).replace(".", ",");
}

