function trocadiv()
{
    // troca simplesmente o conteúdo da div
    $("#div1").html("Etec Itu");
    
}

function trocadiv2()
{
    // troca simplesmente o conteúdo da div
    $("#div1").html($("#frase").val());
    
}


function trocadiv3()
{
    // troca simplesmente o conteúdo da div
    

    $("#div1").load("home.html");
    
}